import React from 'react';
import about from '../../../images/aboutus/aboutus.jpg'

const Aboutus = () => {
    return (
        <div>

            <div className="m-5">
                <img className="w-75" src={about} alt="about us img" />


            </div>

            <div className="pb-5"></div>


        </div>
    );
};

export default Aboutus;