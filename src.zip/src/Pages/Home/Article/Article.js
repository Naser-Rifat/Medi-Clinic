import Button from '@restart/ui/esm/Button';
import React from 'react';
import { Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Article = ({ data }) => {
    const { img, title, description, id } = data;

    return (
        <>
            <Card className=" col-lg-5  mx-5 mb-16 border-2 p-3 hover:shadow-lg">

                <Link className="text-dark no-underline" to={`/articledetails/${id}`}>

                    <div>

                        <Card.Body className="text-left w-100">
                            <Card.Title className="fw-bold">{title}</Card.Title>
                        </Card.Body>

                        <Card.Img className="w-40" variant="top" src={img} />
                    </div>
                </Link>

            </Card>
        </>
    );
};

export default Article;