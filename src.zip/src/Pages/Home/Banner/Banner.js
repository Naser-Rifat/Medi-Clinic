import React from 'react';
import './Banner.css'

const Banner = () => {
    return (
        <div className="row  banner ">

        </div>
    );
};

export default Banner;