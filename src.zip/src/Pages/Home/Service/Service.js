import Button from '@restart/ui/esm/Button';
import React from 'react';
import { Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Service = ({ service }) => {
    const { id, img, title } = service;



    return (



        <Card className=" col-lg-3 mx-10 col-md-8  hover:border-blue-400  border-2 p-2 hover:shadow-lg">
            <Link className="text-dark " to={`/details/${id}`}>
                <Card.Img style={{ height: "250px" }} variant="top" src={img} />
                <Card.Body className="p-4">
                    <Link className="text-dark" to={`/details/${id}`}>
                        <Button className=" fw-bold hover:text-blue-500" > {title}</Button>
                    </Link>
                </Card.Body>
            </Link>
        </Card>




    );
};

export default Service;