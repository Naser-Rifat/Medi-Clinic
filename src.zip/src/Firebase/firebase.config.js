const firebaseConfig = {
    apiKey: "AIzaSyCbRWQ6QVXt9khBQfmBFez4cezPBHIqURE",
    authDomain: "medi-clinic-924d0.firebaseapp.com",
    projectId: "medi-clinic-924d0",
    storageBucket: "medi-clinic-924d0.appspot.com",
    messagingSenderId: "777313651272",
    appId: "1:777313651272:web:c6947f47fbde44ed54667d"
};

export default firebaseConfig;
